#Messaging MVP similar to Slack
